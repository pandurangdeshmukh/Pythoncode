dict = {'Name': 'Zara', 'Age': 7}

print (dict.has_key('Age'))
print ( dict.has_key('Sex'))
