
seq = ('name', 'age', 'sex')

dict = dict.fromkeys(seq,20)
print (("New Dictionary :"), dict)
dict = dict.fromkeys(seq, 10)
print ("New Dictionary : %s" %  str(dict))
