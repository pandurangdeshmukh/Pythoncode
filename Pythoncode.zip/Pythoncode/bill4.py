product={1:"Mouse",2:"keyboard",3:"CPU",4:"MemoryCard",5:"HardDisk",6:"MotherBoard",7:"Pendrive",8:"NIC",9:"Speaker",10:"SMPS"}
price={1:300,2:350,3:8500,4:200,5:4200,6:12000,7:600,8:900,9:1200,10:1800}
card=[]
c=100
c1=1
add=0
GST=0
item=[]
n=int(input("Enter the Product into the card if you want cancel press 0 and continuos prss 1:"))
if n==0:
    print("Thank you")
elif (n!=0)&(n!=1):
    print("Enter Correct Option")
elif n==1: 
    print (product)
    while(c>0):
       # m=int(input("Enter the code of Product:"))
        o=int(input("if you want Add more Press 1:"))
        if o==1:
            m=int(input("Enter the code of Product:"))
            card.append(price[m])
            item.append(product[m])
            while(c1<len(card)):
                add=add+card[c1]
                c1+=1

        if o==0:
            break
    for abc in range(0,len(card)):
        print("your Selected Item:",item[abc],"=",card[abc])
    print ("Addition is:",add)
    GST=add*18/100
    print("18% GST:",GST)
    print("Total Bill is",add+GST)

