a= 22;

if a<20:

    print("a is less than 20")
    print(a)


