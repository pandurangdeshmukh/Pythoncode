n=int(input("Enter any Number:"))
flag=True

for num in range(2,n-1):
    if num >1:
        for num1 in range(2,num):
            if (num%num1==0):
                break
            else:
                print (num)

