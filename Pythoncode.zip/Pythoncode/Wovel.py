test = open('mytext.txt','r')
file1= (test.read())
k=[]
p=[]
q=[]
string1='\t'
string2=''
for b in file1:
    k.append(b)
print(k)
c=0
c1=0
c2=0
c3=0
c4=0
c5=0
c6=0
k1=k.count('a')
k2=k.count('e')
k3=k.count('i')
k4=k.count('o')
k5=k.count('u')
while(c<k1):
    if 'a' in k:
        n=k.index('a')
        p.append(k.pop(n))
        c+=1
while(c1<k2):
    if 'e' in k:
        n1=k.index('e')
        p.append(k.pop(n1))
        c1+=1
while(c2<k3):
    if 'i' in k:
        n2=k.index('i')
        p.append(k.pop(n2))
        c2+=1
while(c3<k4):
    if 'o' in k:
        n3=k.index('o')
        p.append(k.pop(n3))
        c3+=1
while(c4<k5):
    if 'u' in k:
        n4=k.index('u')
        p.append(k.pop(n4))
        c4+=1
print("-----------------WOVEL--------------------------")
print(p)
while(c5<len(p)):
    string1=string1+p[c5]
    c5+=1
print(string1)
while(c6<len(k)):
    string2=string2+k[c6]
    c6+=1
print(string2)
test1=open("wovel.txt","w")
file3=(test1.write(string1))
print("----------------------------")
print(k)
test3=open("consonant.txt","w")
file4=(test3.write(string2))
print("---------------------------")
