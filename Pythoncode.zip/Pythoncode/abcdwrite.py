test = open('abcd.txt','w')
x='kasasdadabad'
y= (test.write(x))
print(y)

