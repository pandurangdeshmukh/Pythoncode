import math

def myinput():
    var=input("Enter any Number")
    return int(var)

def my_sqrt(test):
    return math.sqrt(test)

def my_cube(test1):
    return test1**3


def my_print(var1):
    print(var1)

my_print (my_sqrt(my_cube(myinput())))

