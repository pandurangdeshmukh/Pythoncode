a=1
for abc in range(6,0,-1):
    a=a*abc
print (a)

    

    
