n=int(input("Enter Any Number:"))
flag=True
for count in range(2,n-1): 
    if (n%count==0):
        flag=False

if (flag==False):
    print (n,"is  not prime number")
else:
    print (n,"is  prime number")
