a=["pandurang","sandip","harshal","lijo","amar","raju"]
l1=[]
l2=[]
test=0
b=[]
k=[]
while (test<6):
    b=a[test]
    if (len(b)<=4):
        l1.append(b)

        
    elif (len(b)>=5)&(len(b)<=8):
        l2.append(b)
    elif (len(b)>8):
        k.append(b)
    test+=1
a=k
print (l1)
print (l2)
print (a)
