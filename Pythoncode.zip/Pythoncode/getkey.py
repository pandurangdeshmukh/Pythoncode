
dict = {'Name': 'Zara', 'Age': 27}

a=dict.get("Age","NA")
print ("The Value:",a)
b=dict.get('Gender', "NA")
print ("The Value:",b)
