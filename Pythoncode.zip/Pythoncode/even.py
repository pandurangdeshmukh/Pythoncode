t1=(2,2.5,3,3.5,4,4.5,5,5.5,6,6.5)
L1=[]
L2=[]
L3=[]
c=0
while (c<10):
    L1.append(t1[c]**3)
    if (L1[c]%2==0):
        L2.append(L1[c])
    else:    
        L3.append(L1[c])
    c=c+1

print (L1)
print ("even Value",L2)
print ("Odd value",L3)

