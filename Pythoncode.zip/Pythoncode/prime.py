n=int(input("Enter Any Number:"))
count=2
flag=True
while(count<n): 
    if (n%count==0):
        flag=False
    count+=1

#print (flag)
if (flag==False):
    print (n,"is  not prime number")
else:
    print (n,"is  prime number")
