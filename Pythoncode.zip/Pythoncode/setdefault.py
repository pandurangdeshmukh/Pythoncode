
dict = {'Name': 'Zara', 'Age': 7}
print ("the Value of Age:", dict.setdefault('Age', 28))
print ( "The value of Sex:",dict.setdefault('Sex', None))
print ("the New Directory is dict:",dict)
