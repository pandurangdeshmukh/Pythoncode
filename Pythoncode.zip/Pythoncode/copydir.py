a = {"a":"1","b":"2","c":"3"}
b = {'d':"4"}

a= b.copy()
print (a)
