import string
import random
a=string.ascii_letters
b=string.digits
c=a+b
x=random.sample(c,8)
p=''
q=0
while q<len(x):
    p=p+str(x[q])
    q=q+1
print (p)

k=input("Enter OTP")
while 
if k==p:
    print("correct")

else:
    print("Wrong ")
