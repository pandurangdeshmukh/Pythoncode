flag=True
a=[]
for count in range(2,21):
    if count >1:
        for count2 in (,count):
            if(count%count2==0):
                break
            else:
                a.append(count)
print (a)

#if (flag==False):
#    print (n,"is  not prime number")
#else:
#    print (n,"is  prime number")
#    a.append(n)
#print (a)
