str1=input("Enter string: ")
c=0
l1=[]
while c<len(str1):
    l1.append(str1[c])
    c=c+1
print (l1)    
