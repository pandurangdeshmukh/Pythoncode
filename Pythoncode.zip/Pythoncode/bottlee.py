import time
c=1
l=100
while(c<101):
    l=l-1
    print(l,' bottles of beer on the wall,Take one down and pass it around')
    time.sleep(10)
    c+=1


