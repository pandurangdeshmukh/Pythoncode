set=[]
for x in range (1,100):
    if x%2==0:
        set.append(x) 
print (set)
y=0
z=0
while(y<len(set)):
        z=z+set[y]
        y+=1
        print(z)
    
        
