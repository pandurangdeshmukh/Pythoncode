import os

def myinput():
    c=0
    l=[]
    while (c<4):
        l.append(input("Enter User Name:"))
        c+=1
    return (l)
test=myinput()
print (type(test))
c1=0
while (c1<4):
    os.system("sudo useradd test[c1]")
    c1+=1

