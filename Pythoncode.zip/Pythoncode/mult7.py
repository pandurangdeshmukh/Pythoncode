#n=int(input("Enter Range Between 2000 to 3200"))
count=2000
num=[]
while(count<3200):
    if (count%7==0)&(count*5!=0):
        num.append(count)
    count+=1

print (num)
        
