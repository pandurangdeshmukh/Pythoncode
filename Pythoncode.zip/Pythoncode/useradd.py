import os

def myinput():
    c=0
    l=[]
    while (c<4):
        l.append(input("Enter User Name:"))
        c+=1
    return (l)

def my_useradd():
    a=myinput()
    print(a)
    c1=0
    while (c1<4):
        d=os.system("sudo useradd\t"+a[c1])
        print(d)
        c1+=1
def delete_user():
    a


my_useradd()
#print(k)
