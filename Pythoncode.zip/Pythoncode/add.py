a,b = input("enter two number")
z=a+b
print ("z=",z)


