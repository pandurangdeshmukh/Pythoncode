import random
import string
count=1
print ("WELCOME")
print ("Its a game for number guess ")
user_n=input("Enter your name : ")
user_nm=user_n.capitalize()

gift={1:1000,2:500,3:100}

guess=random.randint(1,10)
print (guess)
def input_nm():
    num=int(input("Enter your guess number between 1 to 10 : "))
    alp=string.ascii_letters
    if num == alp:
        print ("Enter proper guess number : ")
    else:
        print (" Your enter number is " ,num)
    return num
fun=input_nm()
while count<5:
    
    if fun ==guess:
        print (user_nm ," Your guess is correct ")
        if count==1:
            print (user_nm,"you won the gift of price ",gift[1])
        elif count==2:
            print (user_nm,"you won the gift of price ",gift[2])
        elif count==3:
            print (user_nm,"you won the gift of prize ",gift[3])
        input_nm()
        break

    elif fun >= guess:
        print (user_nm ," Your guess number is so high ")
        input_nm()
        break

    elif fun <= guess:
        print (user_nm ," Your guess number is so low ")
        input_nm()
        break

    else:
       print (user_nm," You give a another chance ")
    count+=1
