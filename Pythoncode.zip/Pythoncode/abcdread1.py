test = open('abcd.txt','r')
print (test.read())
