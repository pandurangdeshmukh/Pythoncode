a=1
for abc in range(1,5+1):
    a=a*abc
print (a)

    

    
