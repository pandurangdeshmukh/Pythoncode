#!/usr/bin/python

str = "this is\tstring example....wow!!!";

print "Original string: " + str
print "Defualt exapanded tab: " +  str.expandtabs()
print "Double exapanded tab: " +  str.expandtabs(50)
