DNA='ATGCCTCGGATCGCTGCATCCTTAAACCTACAT'

Pk=DNA.count("AT")
Pk1=DNA.count("A")
Pk2=DNA.count("T")
if "AT" not in DNA:
    print("AT count",PK)
else:
    print("A count",Pk1)
    print("T count",Pk2)
#print("A count",Pk1)
#print("AT Count",Pk)


