prod={10:'CPU',11:"mouse",12:"keyboard",13:"moniter"}
price={10:10000,11:250,12:2000,13:7500}
cart=[]
cart1=[]
count=0
print (prod)
print ("""Enter 1 for product key
        Enter 2 for Billing
        Enter 3 for exit""")
n=input(" Choose option ")

for n in range(1,10):
    
     y=input(" Enter product key: ")
        if n==1:
            cart.append(y)
             print (cart)
             break
        elif n==2:
             cart1.append(cart.values())
             print (cart1)
    count+=1
