import random
import time
import string
def my_random():
    a=random.randint(1,20)
    return (a)

def my_choice():
    p=my_random()
    print(p)
    c=1
    while(c<5):
        x=int(input("\tEnter Your Choice Number:"))
        if x>20:
            print("\tPlease Select Number In between 1-20")
       # elif x==string.punctuation
       #     print("\tNot Allow Special Character")
       # elif x==string.ascii_letters
       #     print("\tNot Allow String Value")

        elif x<21:
          
            if x==p:
                print("win")
                if c==1:
                    print("\t______You win Fridge____")
                elif c==2:
                    print("\t______You win Tv________")
                elif c==3:
                    print("\t______You win Mobile____")
                else:
                    print("\t______You Win Pendrive__")
                break
            else:
                print("lose")
                if x>p:
                    print("\t-----Your Choice is Larger Than  Lucky Number----- ")
                elif x<p:
                    print("\t-----Your Choice is Smaller Than lucky Number-----")
            if c==4:
                print("\tEnd Game")

        c+=1
def start_game():
    print("\n\n--------------------------------WELCOME TO LUCKY DRAW COMPITATION--------------------\n")
    print('''INSTRUCTION:
                1)choose one Number in Between 1-20
                2)In This Game You Have Four Attempt
                3)if Your Choice is Correct in First Attempt then You Win Fridge
                4)if Your Choice is Correct in Second Attempt then You win TV
                5)if Your Choice is Correct in Third Attempt then you win Mobile
                6)if Your Choice is Correct in Fourt Attempt Then You win Pendrive\n\n''')
    time.sleep(15)
    c=1
    while(c<4):
        x=int(input("\tStart Game press 1 OR Cancel game press 0:"))
        if x==1:
            my_choice()
            break
        else:
            print("\tThank you")
            exit()
        

start_game()

