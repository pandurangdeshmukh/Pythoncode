a =100
if a>100:
    print ("The a is less than 100")
elif a<100:
    print ("The a more than 100")  

else:
    print ("a is equal to 100")

