test = open('abcd.txt','r')
a= (test.read())
c=[]
for b in a:
    c.append(b)

print(c)
    

