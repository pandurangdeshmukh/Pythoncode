import math

def myinput():
    c=0
    l=[]
    while (c<4):
        l.append(int(input("Enter any Number")))
        c+=1

    return (l)
        

def my_sqrt(test):
    return math.sqrt(test)

def my_cube(test1):
    return test1**3


def my_print(var1):
    print(var1)

a=myinput()
my_print("List")
my_print(a)
c1=0
while (c1<4):
    print ("Square root of ",a[c1])
    my_print(my_sqrt(a[c1]))
    print ("cube",a[c1])
    my_print(my_cube(a[c1]))
    c1+=1



