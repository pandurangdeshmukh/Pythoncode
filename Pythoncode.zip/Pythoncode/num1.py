import random
a=random.randint(1,4)
c=0
while(c<4):

    n=int(input("Enter Any Number:"))
    if (n==a):
        print("win")
        break;
    else:
        print("lose")
    c+=1
print("Lucky Number is:",a)
print("Your Choice is:",n)
